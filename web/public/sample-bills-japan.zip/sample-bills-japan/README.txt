Sample bills: Takahashi Seimitsu, Kariya, Aichi (Japan). Fiscal year April 2025 to March 2026.

31 files. Drop this zip on the Bills page as it is, or unzip and choose the files.
Each file is here to show something the reader has to cope with:

  elec_2025-04.png                                 printed bill, two meter registers (day and night); the reading check passes
  elec_2025-05.png                                 printed bill, two meter registers (day and night); the reading check passes
  elec_2025-06.png                                 printed bill, two meter registers (day and night); the reading check passes
  elec_2025-06_photo_dup.jpg                       the same June bill photographed again: found as a duplicate and counted once
  elec_2025-07.pdf                                 PDF, not an image; read the same way
  elec_2025-08.png                                 printed bill, two meter registers (day and night); the reading check passes
  elec_2025-09.jpg                                 phone photo taken at an angle, JPEG, slightly soft
  elec_2025-10.png                                 printed bill, two meter registers (day and night); the reading check passes
  elec_2025-11_misprint.png                        misprinted total (a stray digit): the meter readings and the amount disagree, so the check flags it for review
  elec_2025-12.png                                 printed bill, two meter registers (day and night); the reading check passes
  elec_2026-02.png                                 printed bill that follows the missing January: the reconciler asks about the gap
  elec_2026-03.png                                 printed bill, two meter registers (day and night); the reading check passes
  citygas_2025-04_05.png                           city gas in m3 (not kWh), covering two months
  citygas_2025-06_07.png                           city gas in m3 (not kWh), covering two months
  citygas_2025-08_09.png                           city gas in m3 (not kWh), covering two months
  citygas_2025-10_11.pdf                           PDF, two-month city gas bill
  citygas_2025-12_01.png                           city gas in m3 (not kWh), covering two months
  citygas_2026-02_03.png                           city gas in m3 (not kWh), covering two months
  diesel_2025-05.png                               printed delivery note
  diesel_2025-07.png                               printed delivery note
  diesel_2025-08_handwritten.png                   hand-written delivery slip on a pre-printed form, Gregorian date
  diesel_2025-11_scan_rotated.png                  a flatbed scan fed in sideways: the page is rotated 90 degrees and grey
  diesel_2026-02_handwritten_photo.jpg             hand-written slip with a Reiwa-era date (令和8年), then photographed
  petrol_2025-09_handwritten.png                   company-car petrol, hand-written account slip
  lpg_2025-06.png                                  printed LPG invoice, cylinders reported as kg
  lpg_2025-10.png                                  received by fax: black and white, low resolution, with streaks
  lpg_2026-01.pdf                                  PDF LPG invoice
  kerosene_2025-12_handwritten.png                 hand-written kerosene slip: the quantity is cans, the litres are in the note
  kerosene_2026-02_handwritten_photo.jpg           hand-written kerosene slip photographed on a desk
  refrigerant_2025-07.png                          refrigerant fill certificate (フロン類充塡証明書): the kg charged and the blend, R-410A
  refrigerant_2026-01_handwritten.png              hand-written work slip: refrigerant R-32, 3.5 kg, Reiwa-era date

Left out on purpose: electricity for January 2026. The check after reading asks about the gap.
